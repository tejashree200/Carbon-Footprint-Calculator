package com.exampleCarbonCalculator.demo.entity;

public class Transportation {

    float Petrol;
    float Diesel;
    float LPG;
    float Taxi;
    float Bus;
    float AutoRickshaw;
    float Train;

    public Transportation() {
    }

    public Transportation(float petrol, float diesel, float LPG, float taxi, float bus, float autoRickshaw, float train) {
        Petrol = petrol;
        Diesel = diesel;
        this.LPG = LPG;
        Taxi = taxi;
        Bus = bus;
        AutoRickshaw = autoRickshaw;
        Train = train;
    }

    public float getPetrol() {
        return Petrol;
    }

    public void setPetrol(float petrol) {
        Petrol = petrol;
    }

    public float getDiesel() {
        return Diesel;
    }

    public void setDiesel(float diesel) {
        Diesel = diesel;
    }

    public float getLPG() {
        return LPG;
    }

    public void setLPG(float LPG) {
        this.LPG = LPG;
    }

    public float getTaxi() {
        return Taxi;
    }

    public void setTaxi(float taxi) {
        Taxi = taxi;
    }

    public float getBus() {
        return Bus;
    }

    public void setBus(float bus) {
        Bus = bus;
    }

    public float getAutoRickshaw() {
        return AutoRickshaw;
    }

    public void setAutoRickshaw(float autoRickshaw) {
        AutoRickshaw = autoRickshaw;
    }

    public float getTrain() {
        return Train;
    }

    public void setTrain(float train) {
        Train = train;
    }

    public double CalculatePetrol(){
        return Petrol * 2.33;
    }

    public double CalculateDiesel(){
        return Diesel * 2.68;
    }

    public double CalculateLPG(){
        return LPG * 3.06;
    }

    public double CalculateTaxi(){
        return Taxi * 0.31;
    }

    public double CalculateBus(){
        return Bus * 0.05;
    }

    public double CalculateAutoRickshaw(){
        return AutoRickshaw * 0.05;
    }

    public double CalculateTrain(){
        return Train * 0.10;
    }
    public double CalculateTotalEmissions(){
        double petrol = CalculatePetrol();
        double diesel = CalculateDiesel();
        double lpg = CalculateLPG();
        double taxi = CalculateTaxi();
        double bus = CalculateBus();
        double auto = CalculateAutoRickshaw();
        double train = CalculateTrain();
        return petrol+diesel+lpg+taxi+bus+auto+train;
    }
}
