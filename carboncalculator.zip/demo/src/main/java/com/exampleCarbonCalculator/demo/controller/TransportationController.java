package com.exampleCarbonCalculator.demo.controller;

import com.exampleCarbonCalculator.demo.entity.Transportation;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class TransportationController {

    @GetMapping("/calculate")
    public String Calculate(Model model){
        return "home";
    }

    @GetMapping("/calculate/transportation")
    public String TransportationForm(Model model){
        Transportation transportation = new Transportation();
        model.addAttribute("calculation",transportation);

        return "transportationForm";
    }

    @PostMapping("/calculate")
    public String CalculationForm(@ModelAttribute("calculation") Transportation transportation){
        transportation.CalculatePetrol();
        transportation.CalculateDiesel();
        transportation.CalculateLPG();
        transportation.CalculateTaxi();
        transportation.CalculateBus();
        transportation.CalculateAutoRickshaw();
        transportation.CalculateTrain();
        transportation.CalculateTotalEmissions();
        return "transportationForm";
    }
}
